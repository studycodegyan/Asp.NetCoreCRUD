﻿namespace UserPortal.Web.Models.Entities
{
    public class Users
    {
        public Guid Id { get; set; }
        public string fName { get; set; }=string.Empty;
        public string lName { get; set; } = string.Empty;
		public int Age { get; set; } = 0;
		public int Gender { get; set; } = 0;
		public string MobileNo { get; set; } = string.Empty;
		public string Addres { get; set; } = string.Empty;
		public string district { get; set;} = string.Empty;
		public string States { get; set; } = string.Empty;
		public string Country { get; set; } = string.Empty;
		public string Designation { get; set; } = string.Empty;
	}
}
