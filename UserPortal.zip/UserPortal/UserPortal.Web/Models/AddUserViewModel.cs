﻿namespace UserPortal.Web.Models
{
    public class AddUserViewModel
    {
        required
        public string fName { get; set; }
        public string lName { get; set; }
        public int Age { get; set; } = 0;
        public int Gender { get; set; } = 0;
        public string MobileNo { get; set; } = null;
        public string Addres { get; set; } = null;
        public string district { get; set; } = null;
        public string States { get; set; } = null;
        public string Country { get; set; } = null;
        public string Designation { get; set; } = null;
    }
}
