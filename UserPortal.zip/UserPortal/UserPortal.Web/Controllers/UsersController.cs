﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserPortal.Web.Data;
using UserPortal.Web.Models;
using UserPortal.Web.Models.Entities;

namespace UserPortal.Web.Controllers
{
	public class UsersController : Controller
	{
		private readonly ApplicationDbContext dbContext;

		public UsersController(ApplicationDbContext dbContext)
		{
			this.dbContext = dbContext;
		}

		[HttpGet]
		public IActionResult AddUsers()
		{
			return View();
		}

		[HttpPost]
		public async Task<IActionResult> AddUsers(AddUserViewModel viewModel)
		{
			var users = new Users
			{
				fName = viewModel.fName,
				lName = viewModel.lName,
				Age = viewModel.Age,
				Gender = viewModel.Gender,
				Addres = viewModel.Addres,
				district = viewModel.district,
				States = viewModel.States,
				Country = viewModel.Country,
				Designation = viewModel.Designation
			};

			await dbContext.Users.AddAsync(users);
			await dbContext.SaveChangesAsync();

			return View();
		}

		[HttpGet]
		public async Task<IActionResult> usersList()
		{
			var userList = dbContext.Users.ToList();
			//var userList = await dbContext.Users.ToListAsync();

			return View(userList);
		}

		[HttpGet]
		public async Task<IActionResult> EditUser(Guid id)
		{
			var users = await dbContext.Users.FindAsync(id);

			return View(users);
		}

		[HttpPost]
		public async Task<IActionResult> EditUser(Users viewModel)
		{
			var user = await dbContext.Users.FindAsync(viewModel.Id);

			if(user is not null)
			{
				user.fName = viewModel.fName;
				user.lName = viewModel.lName;
				user.Age = viewModel.Age;
				user.Gender = viewModel.Gender;
				user.Addres = viewModel.Addres;
				user.district = viewModel.district;
				user.States = viewModel.States;
				user.Country = viewModel.Country;
				user.Designation = viewModel.fName;
				user.MobileNo = viewModel.MobileNo;

				await dbContext.SaveChangesAsync();
			}

			return RedirectToAction("usersList", "Users");

		}

		[HttpPost]
		public async Task<IActionResult> DeleteUser(Users viewModel)
		{
			var user = await dbContext.Users
				.AsNoTracking()
				.FirstOrDefaultAsync(x =>x.Id == viewModel.Id);

			if(user is not null)
			{
				dbContext.Users.Remove(viewModel);
				await dbContext.SaveChangesAsync();
			}

			return RedirectToAction("usersList", "Users");
		}
	}
}
