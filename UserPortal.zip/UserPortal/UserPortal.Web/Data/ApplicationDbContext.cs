﻿using Microsoft.EntityFrameworkCore;
using UserPortal.Web.Models.Entities;

namespace UserPortal.Web.Data
{
    public class ApplicationDbContext :DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options)
        {
        }

        public DbSet<Users> Users { get; set; }
    }
}
